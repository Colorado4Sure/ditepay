module.exports = {
  secret: "popnaija-secret-key"
};


