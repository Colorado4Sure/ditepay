const db = require("../models");
const User = db.user;

exports.allAccess = (req, res) => {
  res.status(200).send("Public Content.");
};

exports.userBoard = (req, res) => {
  res.status(200).send("User Content.");
};

//User Account details Export
exports.userAccount = (req, res) => {
    User.findOne({
      where: {
        login_token: req.login_token
      }
    })
      .then(user => {
        if (!user) {
          return res.status(404).send({ message: "User Not found or user session expired. Please Login again" });
        }
        // var authorities = [];
        user.getRoles().then(roles => {
          res.status(200).send({
            id: user.id,
            firstName: user.fname,
            lastName: user.lname,
            username: user.username,
            email: user.email,
            phone: user.phone,
            gender: user.gender,
            date_of_birth: user.dob,
            email_verified: user.email_verified,
            profile_pic: user.profilepic,
            account_number: user.custom_account_number,
            account_name: user.custom_account_name,
            account_bank: user.custom_account_bank,
            account_ref: user.custom_account_ref,
            is_developer: user.is_developer,
            balance: user.balance,
            referral_commision: user.referral_commision,
            points: user.points,
            last_login: user.last_login,
            // roles: authorities,
            // accessToken: token
          });
        });
      })
      .catch(err => {
        res.status(500).send({ message: err.message });
      });
  // res.status(200).send(acc);
};
// User Account Export Ends Here

// Update User Data Starts Here
exports.userAccountUpdate = (req, res) => {
  User.findOne({
    where: {
      login_token: req.login_token
    }
  })
    .then(user => {
      if (!user) return res.status(404).send({ message: "User Not found or user session expired. Please Login again" });

      User.update({
        fname: req.body.firstName,
        lname: req.body.lastName,
        dob: req.body.dob,
        phone: req.body.phone,
        gender: req.body.gender,
        profilepic: req.body.profile_pics,
        custom_account_number: req.body.account_number,
        custom_account_name: req.body.account_name,
        custom_account_bank: req.body.account_bank,
        is_developer: req.body.developer_mode
      }, 
      {
        where: {
          id: user.id
        }
      })

      user.getRoles().then(roles => {
        res.status(200).send({
          message: "Udated Successfully",
          data: req.body
        })
      })
    })
    .catch(err => {
      res.status(500).send({ message: err.message });
    });
// res.status(200).send(acc);
};

exports.generate = (req, res) =>{
  'use strict';

const { networkInterfaces } = require('os');

const nets = networkInterfaces();
const results = Object.create(null); // Or just '{}', an empty object

for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
        // Skip over non-IPv4 and internal (i.e. 127.0.0.1) addresses
        if (net.family === 'IPv4' && !net.internal) {
            if (!results[name]) {
                results[name] = [];
            }
            results[name].push(net.address);
        }
    }
}
  res.send(results);
}

exports.adminBoard = (req, res) => {
  res.status(200).send("Admin Content.");
};

exports.moderatorBoard = (req, res) => {
  res.status(200).send("Moderator Content.");
};
