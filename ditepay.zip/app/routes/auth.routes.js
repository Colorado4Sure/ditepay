const { verifySignUp, authJwt } = require("../middleware");
const controller = require("../controllers/auth.controller");

module.exports = function(app) {
  app.use(function(req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  app.post(
    "/api/auth/signup",
    [
      verifySignUp.checkDuplicateUsernameOrEmail,
      verifySignUp.checkRolesExisted
    ],
    controller.signup
  );
  app.post("/api/auth/verify", controller.email_verify);
  app.put("/api/auth/verify", controller.resend_email_verify);
  app.post("/api/auth/signin", controller.signin);
  app.post("/api/auth/reset", controller.reset);
  app.put("/api/auth/reset", controller.reset_email);
  app.patch("/api/auth/reset", [authJwt.verifyToken], controller.changePass);

};
