module.exports = (sequelize, Sequelize) => {
  const User = sequelize.define("users", {
    fname: {
      type: Sequelize.STRING
    },
    lname: {
      type: Sequelize.STRING
    },
    username: {
      type: Sequelize.STRING
    },
    email: {
      type: Sequelize.STRING
    },
    password: {
      type: Sequelize.STRING
    },
    balance: {
      type: Sequelize.DECIMAL(10,1)
    },
    points: {
      type: Sequelize.INTEGER
    },
    phone: {
      type: Sequelize.STRING
    },
    gender: {
      type: Sequelize.STRING
    },
    dob: {
      type: Sequelize.STRING
    },
    email_verified: {
      type: Sequelize.INTEGER
    },
    profilepic: {
      type: Sequelize.STRING
    },
    referral_commision: {
      type: Sequelize.STRING
    },
    is_developer: {
      type: Sequelize.STRING
    },
    custom_account_number: {
      type: Sequelize.STRING
    },
    custom_account_name: {
      type: Sequelize.STRING
    },
    custom_account_bank: {
      type: Sequelize.STRING
    },
    custom_account_ref: {
      type: Sequelize.STRING
    },
    monnify_account_ref: {
      type: Sequelize.STRING
    },
    login_token: {
      type: Sequelize.STRING
    },
    last_login: {
      type: Sequelize.STRING
    },
    email_reset: {
      type: Sequelize.INTEGER
    }
  });

  return User;
};
